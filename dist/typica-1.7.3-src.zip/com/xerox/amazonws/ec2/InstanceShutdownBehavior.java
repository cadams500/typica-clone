package com.xerox.amazonws.ec2;

/**
 * @author Eugene Petrenko (eugene.petrenko@gmail.com)
 *         Date: 26.05.11 20:07
 */
public enum InstanceShutdownBehavior {
  STOP,
  TERMINATE,
  ;
}
