package com.xerox.amazonws.fps;

public enum RecurringGranularity {
    HOUR("Hour"), DAY("Day"), MONTH("Month");

    private String value;

    RecurringGranularity(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
